package ast;

public abstract class NodeExpr extends NodeAST {

}