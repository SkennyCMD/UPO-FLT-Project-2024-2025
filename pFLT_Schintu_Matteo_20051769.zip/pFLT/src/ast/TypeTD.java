package ast;

public enum TypeTD {
	INT,
	FLOAT,
	OK,
	ERROR
}
