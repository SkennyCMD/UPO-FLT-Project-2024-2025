package ast;

public enum LangOper {
	PLUS,
	MINUS,
	TIMES,
	DIV,
	DIV_FLOAT
}
