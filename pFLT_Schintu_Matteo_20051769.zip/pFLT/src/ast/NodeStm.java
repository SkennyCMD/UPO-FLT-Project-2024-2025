package ast;

public abstract class NodeStm extends NodeDecSt{

}
