package ast;

public enum LangType {
	INT,
	FLOAT
}
